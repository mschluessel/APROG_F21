﻿using System;

namespace SW08_AbstractShape {
    class Program {
        static void Main( string[] args ) {

            Shape s1 = new Circle( 1 ); // initialize diameter (d)
            Shape s2 = new Rectangle( 1, 1 ); // intialize dimension (w x h)

            ShapeContainer sc = new ShapeContainer();

            sc.Add( s1 );
            sc.Add( s2 );

            sc.DrawAll();
        }
    }
}
