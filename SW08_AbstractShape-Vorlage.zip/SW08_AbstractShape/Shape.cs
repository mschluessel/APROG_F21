﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SW08_AbstractShape {
    public class Shape {
        protected int xPos;
        protected int yPos;

        public Shape() {
            // Console.WriteLine( "in Shape()" );
        }

        public Shape( int x, int y ) {
            // Console.WriteLine( "in Shape(int, int)" );
            xPos = x;
            yPos = y;
        }

        public ConsoleColor Color { get; set; }

        public void Move( int xPos, int yPos ) {
            this.xPos = xPos;
            this.yPos = yPos;
        }

        public virtual void Draw() {
            Console.WriteLine( $"Draw Shape at pos {xPos}:{yPos}" );
        }

    } // end class Shape
} // end namspace
