﻿using System;
using Unosquare.RaspberryIO;
using Unosquare.RaspberryIO.Abstractions;
using Unosquare.WiringPi;
using System.Threading;
using Utils;


namespace Testat_Game
{
    class Program
    {
        static void Main(string[] args)
        {

            Util.WaitForDebugger();

            Pi.Init<BootstrapWiringPi>();

            //Objecte erstellen
            HighscoreList hlist = new HighscoreList();
            LED led = new LED();
            System.Diagnostics.Stopwatch s = new System.Diagnostics.Stopwatch();

            
            Console.WriteLine("------------------------");
            Console.WriteLine("Catch The BlinkyS");
            Console.WriteLine("------------------------\n\n");

            //Spiel infos
            Console.WriteLine("Reagiere möglist schnell und bewege den Joystick in die richtige Richtung ");
            Console.WriteLine("LED2 (Gelb) = Joystick nach links");
            Console.WriteLine("LED3 (Grün) = Joystick drücken");
            Console.WriteLine("LED4 (Blau) = Joystick nach rechts");
            Console.WriteLine("Die LED1 (Rot) gibt dir ein 3 Sekunden Countdown wenn das Spiel beginnt");

            while (true) //Solange true bis nicht weiter gespielt werden will
            {
                Console.WriteLine("\nBist du bereit? press enter");
                Console.ReadKey();

                //Start Countdown
                for (int i = 0; i < 3; i++)
                {
                    Thread.Sleep(400);
                    led.ledRed.PinMode = GpioPinDriveMode.Output; 
                    led.ledRed.Write(true);
                    Thread.Sleep(600);
                    led.ledRed.Write(false);
                }

                //Joystick joyStick = new Joystick();

                int BCMPush = 26;
                int BCMLeft = 6;
                int BCMRight = 5;

                //GPIO Pin von Joystick definieren
                IGpioPin joystickPush = Pi.Gpio[BCMPush];
                IGpioPin joystickLeft = Pi.Gpio[BCMLeft];
                IGpioPin joystickRight = Pi.Gpio[BCMRight];
                
                //Joystick als Eingang definieren
                joystickPush.PinMode = GpioPinDriveMode.Input;
                joystickLeft.PinMode = GpioPinDriveMode.Input;
                joystickRight.PinMode = GpioPinDriveMode.Input;
                

                int GetJoystickPosition()
                {

                    if (joystickLeft.Read() == false)
                    {
                        return 1;
                    }

                    if (joystickPush.Read() == false)
                    {
                        return 2;
                    }

                    if (joystickRight.Read() == false)
                    {
                        return 3;
                    }

                    return 0;
                }


                s.Reset();  //Reset Zeitmessung

                s.Start();  //Start Zeitmessung


                for (int i = 0; i < 10; i++)
                {
                    int n = led.GetLED();
                    int j = GetJoystickPosition();
                    while (n != j)
                    {
                        j = GetJoystickPosition();
                    }
                    led.SetLEDOff();

                }

                s.Stop(); //Stop Zeitmessung
                TimeSpan timeSpan = s.Elapsed; //Differenz berechnen
                Console.WriteLine($"\nTime: {timeSpan.Seconds}s {timeSpan.Milliseconds}ms\n");

                //hlist.CheckHighscore(timeSpan);
                hlist.HighscoreAdd(timeSpan);

                //Highscoreliste ausgeben
                hlist.PrintHighscoreList();

                //nochmals Spielen
                Console.WriteLine("\nNochmals spielen? J/n");


                if (Console.ReadKey().Key == ConsoleKey.N)
                {
                    break;
                }

            }
            Console.WriteLine("\nProgram END");






        }
    }
}