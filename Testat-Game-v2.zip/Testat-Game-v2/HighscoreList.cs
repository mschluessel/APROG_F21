﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testat_Game {
    class HighscoreList {

        private static int capacity = 10;
        private int count = 0;

        private bool newHighscore = false;

        List<TimeSpan> highscoreList = new List<TimeSpan>(capacity);

        public void HighscoreAdd(TimeSpan score) {

            if (count > 0) {
                CheckHighscore(score);
            }
            
            if (count==capacity) {
                if (score < highscoreList[9]) {
                    highscoreList.RemoveAt(9);
                    highscoreList.Add(score);
                    highscoreList.Sort();
                    if (!newHighscore) {
                        Console.WriteLine("Glückwunsch du hast es in die Top 10 geschafft!");
                    }
                    return;
                }
                else {
                    Console.WriteLine("Du hast es leider nicht in die Top 10 geschafft.");
                    return;
                }
            }

            highscoreList.Add(score);
            highscoreList.Sort();
            count++;

            if (!newHighscore) {
                Console.WriteLine("Glückwunsch du hast es in die Top 10 geschafft!");
            }

            return;
        }

        public void PrintHighscoreList() {

            Console.WriteLine("\n-----------");
            Console.WriteLine("Top 10");
            Console.WriteLine("-----------");

            for (int i = 0; i < count; i++) {
                Console.Write($"{i+1}: ");
                string output = highscoreList[i].ToString(@"ss\.fff");
                Console.WriteLine($"{output} s");
            }
        }

        public void CheckHighscore(TimeSpan score)
        {
            if(score < highscoreList[0])
            {
                Console.WriteLine("NEW HIGHSCORE!!!!");
                newHighscore = true;
            }
        }
    }
}
